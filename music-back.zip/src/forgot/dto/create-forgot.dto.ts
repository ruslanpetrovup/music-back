export class CreateForgotDto {}
