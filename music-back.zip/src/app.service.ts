import { Injectable, Redirect } from '@nestjs/common';

@Injectable()
export class AppService {}
